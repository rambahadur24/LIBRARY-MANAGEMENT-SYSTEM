<?php
/**
 * AJAX ISBN Validation Handler
 */

require_once '../config/config.php';
require_once '../models/Book.php';

header('Content-Type: application/json');

if (!Security::isLoggedIn()) {
    Response::error('Unauthorized', 401);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    Response::error('Invalid request method');
}

$isbn = Security::sanitizeInput($_POST['isbn'] ?? '');
$excludeId = isset($_POST['exclude_id']) ? intval($_POST['exclude_id']) : null;

if (empty($isbn)) {
    Response::error('ISBN is required');
}

try {
    $bookModel = new Book();
    $exists = $bookModel->isbnExists($isbn, $excludeId);
    
    Response::json([
        'success' => true,
        'exists' => $exists,
        'message' => $exists ? 'This ISBN already exists' : 'ISBN is available'
    ]);
} catch (Exception $e) {
    error_log('ISBN check error: ' . $e->getMessage());
    Response::error('An error occurred');
}
?>
