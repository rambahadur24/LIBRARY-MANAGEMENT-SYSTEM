<?php
/**
 * AJAX Get Member Info Handler
 */

require_once '../config/config.php';
require_once '../models/Member.php';
require_once '../models/Loan.php';

header('Content-Type: application/json');

if (!Security::isLoggedIn()) {
    Response::error('Unauthorized', 401);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    Response::error('Invalid request method');
}

$memberId = isset($_POST['member_id']) ? intval($_POST['member_id']) : 0;

if ($memberId <= 0) {
    Response::error('Invalid member ID');
}

try {
    $memberModel = new Member();
    $loanModel = new Loan();
    
    $member = $memberModel->getById($memberId);
    
    if (!$member) {
        Response::error('Member not found');
    }
    
    $activeLoans = $loanModel->getMemberLoans($memberId, 'active');
    
    Response::json([
        'success' => true,
        'member' => [
            'id' => $member['member_id'],
            'name' => $member['first_name'] . ' ' . $member['last_name'],
            'email' => $member['email'],
            'status' => $member['status'],
            'type' => $member['membership_type'],
            'active_loans' => count($activeLoans)
        ]
    ]);
} catch (Exception $e) {
    error_log('Member info error: ' . $e->getMessage());
    Response::error('An error occurred');
}
?>
