<?php
/**
 * AJAX Autocomplete Handler
 * Provides autocomplete suggestions for search fields
 */

require_once '../config/config.php';
require_once '../models/Book.php';

// Set JSON header
header('Content-Type: application/json');

// Check if user is logged in
if (!Security::isLoggedIn()) {
    Response::error('Unauthorized', 401);
}

// Validate request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    Response::error('Invalid request method');
}

// Get and validate input
$query = Security::sanitizeInput($_POST['query'] ?? '');
$field = Security::sanitizeInput($_POST['field'] ?? 'title');

// Validate query length
if (strlen($query) < 2) {
    Response::json(['suggestions' => []]);
}

// Validate field
$allowedFields = ['title', 'author', 'isbn'];
if (!in_array($field, $allowedFields)) {
    Response::error('Invalid field parameter');
}

try {
    $bookModel = new Book();
    $suggestions = $bookModel->autocomplete($query, $field);
    
    Response::json([
        'success' => true,
        'suggestions' => $suggestions,
        'query' => $query,
        'field' => $field
    ]);
    
} catch (Exception $e) {
    error_log('Autocomplete error: ' . $e->getMessage());
    Response::error('An error occurred while fetching suggestions');
}
?>