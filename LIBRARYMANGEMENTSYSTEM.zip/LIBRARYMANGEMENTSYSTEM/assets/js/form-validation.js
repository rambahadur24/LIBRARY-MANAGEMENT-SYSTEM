/**
 * Form Validation JavaScript
 */

class FormValidator {
    constructor(formSelector, options = {}) {
        this.form = document.querySelector(formSelector);
        this.options = options;
        
        if (this.form) {
            this.init();
        }
    }
    
    init() {
        this.form.addEventListener('submit', this.validate.bind(this));
        
        // Real-time validation
        this.form.querySelectorAll('input, textarea, select').forEach(field => {
            field.addEventListener('blur', this.validateField.bind(this));
        });
    }
    
    validate(e) {
        let isValid = true;
        
        this.form.querySelectorAll('input, textarea, select').forEach(field => {
            if (!this.validateField(field)) {
                isValid = false;
            }
        });
        
        if (!isValid) {
            e.preventDefault();
        }
        
        return isValid;
    }
    
    validateField(field) {
        let isValid = true;
        const value = field.value.trim();
        const type = field.type;
        
        // Clear previous error
        this.removeError(field);
        
        // Check required
        if (field.required && value === '') {
            this.showError(field, 'This field is required');
            return false;
        }
        
        // Check email
        if (type === 'email' && value !== '') {
            if (!this.validateEmail(value)) {
                this.showError(field, 'Please enter a valid email');
                return false;
            }
        }
        
        // Check number
        if (type === 'number' && value !== '') {
            if (isNaN(value)) {
                this.showError(field, 'Please enter a valid number');
                return false;
            }
            
            if (field.min && parseInt(value) < parseInt(field.min)) {
                this.showError(field, `Value must be at least ${field.min}`);
                return false;
            }
            
            if (field.max && parseInt(value) > parseInt(field.max)) {
                this.showError(field, `Value cannot exceed ${field.max}`);
                return false;
            }
        }
        
        // Check phone
        if (type === 'tel' && value !== '') {
            if (!this.validatePhone(value)) {
                this.showError(field, 'Please enter a valid phone number');
                return false;
            }
        }
        
        // Check URL
        if (type === 'url' && value !== '') {
            if (!this.validateUrl(value)) {
                this.showError(field, 'Please enter a valid URL');
                return false;
            }
        }
        
        return isValid;
    }
    
    validateEmail(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }
    
    validatePhone(phone) {
        const regex = /^\d{10}$|^[\d-]{12}$|^[\d\s]{10,}$/;
        return regex.test(phone.replace(/\D/g, ''));
    }
    
    validateUrl(url) {
        try {
            new URL(url);
            return true;
        } catch (e) {
            return false;
        }
    }
    
    showError(field, message) {
        field.classList.add('error');
        field.style.borderColor = '#ef4444';
        
        const errorDiv = document.createElement('small');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        errorDiv.style.color = '#ef4444';
        
        field.parentNode.appendChild(errorDiv);
    }
    
    removeError(field) {
        field.classList.remove('error');
        field.style.borderColor = '';
        
        const errorMsg = field.parentNode.querySelector('.error-message');
        if (errorMsg) {
            errorMsg.remove();
        }
    }
}

// Initialize form validators on page load
document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        new FormValidator(form);
    });
});
