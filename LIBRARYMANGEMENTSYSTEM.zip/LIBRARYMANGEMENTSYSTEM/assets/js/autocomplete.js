/**
 * Autocomplete functionality for search forms
 * Uses AJAX to fetch suggestions from the server
 */

document.addEventListener('DOMContentLoaded', function() {
    // Get all autocomplete inputs
    const autocompleteInputs = document.querySelectorAll('.autocomplete');
    
    autocompleteInputs.forEach(input => {
        const field = input.getAttribute('data-field');
        const suggestionsDiv = document.getElementById(`${field}-suggestions`);
        
        if (!suggestionsDiv) return;
        
        let debounceTimer;
        let currentFocus = -1;
        
        // Input event listener with debouncing
        input.addEventListener('input', function() {
            clearTimeout(debounceTimer);
            const query = this.value.trim();
            
            // Clear suggestions if query is too short
            if (query.length < 2) {
                suggestionsDiv.innerHTML = '';
                suggestionsDiv.classList.remove('active');
                return;
            }
            
            // Debounce AJAX request
            debounceTimer = setTimeout(() => {
                fetchSuggestions(query, field, suggestionsDiv, input);
            }, 300);
        });
        
        // Keyboard navigation
        input.addEventListener('keydown', function(e) {
            const items = suggestionsDiv.querySelectorAll('.suggestion-item');
            
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                currentFocus++;
                addActive(items);
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                currentFocus--;
                addActive(items);
            } else if (e.key === 'Enter') {
                e.preventDefault();
                if (currentFocus > -1 && items[currentFocus]) {
                    items[currentFocus].click();
                }
            } else if (e.key === 'Escape') {
                suggestionsDiv.innerHTML = '';
                suggestionsDiv.classList.remove('active');
                currentFocus = -1;
            }
        });
        
        function addActive(items) {
            if (!items || items.length === 0) return;
            
            removeActive(items);
            
            if (currentFocus >= items.length) currentFocus = 0;
            if (currentFocus < 0) currentFocus = items.length - 1;
            
            items[currentFocus].classList.add('active');
        }
        
        function removeActive(items) {
            items.forEach(item => item.classList.remove('active'));
        }
        
        // Close suggestions when clicking outside
        document.addEventListener('click', function(e) {
            if (e.target !== input && e.target !== suggestionsDiv) {
                suggestionsDiv.innerHTML = '';
                suggestionsDiv.classList.remove('active');
                currentFocus = -1;
            }
        });
    });
});

/**
 * Fetch suggestions from server via AJAX
 */
function fetchSuggestions(query, field, suggestionsDiv, input) {
    const formData = new FormData();
    formData.append('query', query);
    formData.append('field', field);
    
    fetch('../ajax/autocomplete.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.success && data.suggestions) {
            displaySuggestions(data.suggestions, suggestionsDiv, input);
        } else {
            suggestionsDiv.innerHTML = '';
            suggestionsDiv.classList.remove('active');
        }
    })
    .catch(error => {
        console.error('Autocomplete error:', error);
        suggestionsDiv.innerHTML = '<div class="suggestion-error">Error loading suggestions</div>';
    });
}

/**
 * Display suggestions in dropdown
 */
function displaySuggestions(suggestions, suggestionsDiv, input) {
    suggestionsDiv.innerHTML = '';
    
    if (suggestions.length === 0) {
        suggestionsDiv.innerHTML = '<div class="suggestion-empty">No suggestions found</div>';
        suggestionsDiv.classList.add('active');
        return;
    }
    
    suggestions.forEach(suggestion => {
        const div = document.createElement('div');
        div.className = 'suggestion-item';
        div.textContent = suggestion;
        
        div.addEventListener('click', function() {
            input.value = suggestion;
            suggestionsDiv.innerHTML = '';
            suggestionsDiv.classList.remove('active');
            input.focus();
        });
        
        suggestionsDiv.appendChild(div);
    });
    
    suggestionsDiv.classList.add('active');
}

/**
 * Utility function to escape HTML
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}