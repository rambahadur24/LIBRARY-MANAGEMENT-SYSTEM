-- Library Management System Database Schema

CREATE DATABASE IF NOT EXISTS library_management;
USE library_management;

-- Books table
CREATE TABLE IF NOT EXISTS books (
    book_id INT AUTO_INCREMENT PRIMARY KEY,
    isbn VARCHAR(20) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    publisher VARCHAR(255),
    publication_year INT,
    genre VARCHAR(100),
    pages INT,
    copies_available INT DEFAULT 1,
    total_copies INT DEFAULT 1,
    description TEXT,
    cover_image VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_title (title),
    INDEX idx_author (author),
    INDEX idx_genre (genre),
    INDEX idx_year (publication_year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Members table
CREATE TABLE IF NOT EXISTS members (
    member_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    membership_date DATE NOT NULL,
    membership_type ENUM('student', 'faculty', 'public') DEFAULT 'public',
    status ENUM('active', 'suspended', 'expired') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_name (last_name, first_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Loans table
CREATE TABLE IF NOT EXISTS loans (
    loan_id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT NOT NULL,
    member_id INT NOT NULL,
    loan_date DATE NOT NULL,
    due_date DATE NOT NULL,
    return_date DATE NULL,
    status ENUM('active', 'returned', 'overdue') DEFAULT 'active',
    fine_amount DECIMAL(10, 2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE CASCADE,
    FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE CASCADE,
    INDEX idx_status (status),
    INDEX idx_dates (loan_date, due_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Admin users table (for authentication)
CREATE TABLE IF NOT EXISTS admin_users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    role ENUM('admin', 'librarian') DEFAULT 'librarian',
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sample admin user (password: admin123)
INSERT INTO admin_users (username, password_hash, full_name, email, role) 
VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', 'admin@library.edu', 'admin');

-- Insert sample books
INSERT INTO books (isbn, title, author, publisher, publication_year, genre, pages, copies_available, total_copies, description) VALUES
('978-0-13-468599-1', 'Clean Code', 'Robert C. Martin', 'Prentice Hall', 2008, 'Technology', 464, 3, 3, 'A handbook of agile software craftsmanship'),
('978-0-596-52068-7', 'JavaScript: The Good Parts', 'Douglas Crockford', 'O\'Reilly Media', 2008, 'Technology', 176, 2, 2, 'Unearthing the excellence in JavaScript'),
('978-0-134-68599-1', 'The Pragmatic Programmer', 'Andrew Hunt', 'Addison-Wesley', 2019, 'Technology', 352, 4, 4, 'Your journey to mastery'),
('978-0-061-96436-7', 'Dune', 'Frank Herbert', 'Ace Books', 2019, 'Science Fiction', 688, 5, 5, 'Epic science fiction masterpiece'),
('978-0-547-92821-7', 'The Hobbit', 'J.R.R. Tolkien', 'Mariner Books', 2012, 'Fantasy', 310, 3, 3, 'A timeless classic of fantasy literature'),
('978-0-451-52493-5', '1984', 'George Orwell', 'Signet Classic', 1950, 'Science Fiction', 328, 6, 6, 'Dystopian social science fiction'),
('978-0-316-76948-0', 'The Catcher in the Rye', 'J.D. Salinger', 'Little, Brown', 1951, 'Fiction', 277, 2, 2, 'Classic American literature'),
('978-1-501-11061-8', 'The Testaments', 'Margaret Atwood', 'Anchor Books', 2023, 'Science Fiction', 432, 4, 4, 'Sequel to The Handmaid\'s Tale'),
('978-0-593-31122-7', 'Project Hail Mary', 'Andy Weir', 'Ballantine Books', 2023, 'Science Fiction', 496, 3, 3, 'Thrilling space adventure'),
('978-1-250-30270-7', 'Network Effect', 'Martha Wells', 'Tordotcom', 2023, 'Science Fiction', 352, 2, 2, 'Murderbot Diaries series');

-- Insert sample members
INSERT INTO members (first_name, last_name, email, phone, address, membership_date, membership_type, status) VALUES
('John', 'Doe', 'john.doe@email.com', '555-0101', '123 Main St, City', '2023-01-15', 'student', 'active'),
('Jane', 'Smith', 'jane.smith@email.com', '555-0102', '456 Oak Ave, City', '2023-02-20', 'faculty', 'active'),
('Bob', 'Johnson', 'bob.johnson@email.com', '555-0103', '789 Pine Rd, City', '2023-03-10', 'public', 'active'),
('Alice', 'Williams', 'alice.williams@email.com', '555-0104', '321 Elm St, City', '2023-04-05', 'student', 'active'),
('Charlie', 'Brown', 'charlie.brown@email.com', '555-0105', '654 Maple Dr, City', '2023-05-12', 'public', 'active');