<?php
/**
 * Header Template
 */
if (!defined('APP_NAME')) {
    die('Direct access not permitted');
}
?>
<header class="header">
    <div class="header-container">
        <a href="/LIBRARYMANGEMENTSYSTEM/index.php" class="logo">
            📚 <?php echo APP_NAME; ?>
        </a>
        
        <nav>
            <ul class="nav-menu">
                <li><a href="/LIBRARYMANGEMENTSYSTEM/index.php">Dashboard</a></li>
                <li><a href="/LIBRARYMANGEMENTSYSTEM/books/search.php">Search Books</a></li>
                <li><a href="/LIBRARYMANGEMENTSYSTEM/books/list.php">All Books</a></li>
                <li><a href="/LIBRARYMANGEMENTSYSTEM/members/list.php">Members</a></li>
                <li><a href="/LIBRARYMANGEMENTSYSTEM/loans/list.php">Loans</a></li>
            </ul>
        </nav>
        
        <div class="user-info">
            <span class="user-name">
                👤 <?php echo Security::sanitizeInput($_SESSION['full_name'] ?? 'User'); ?>
            </span>
            <a href="/LIBRARYMANGEMENTSYSTEM/logout.php" class="btn btn-sm btn-secondary">Logout</a>
        </div>
    </div>
</header>