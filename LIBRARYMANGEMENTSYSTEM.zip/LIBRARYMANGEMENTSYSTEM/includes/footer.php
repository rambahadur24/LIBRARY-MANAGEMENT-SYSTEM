<?php
/**
 * Footer Template
 */
if (!defined('APP_NAME')) {
    die('Direct access not permitted');
}
?>
<footer class="footer">
    <div class="footer-container">
        <div class="footer-content">
            <div class="footer-section">
                <div class="footer-logo">📚 <?php echo APP_NAME; ?></div>
                <p>A comprehensive library management system for efficient book and member management.</p>
                <div class="footer-social">
                    <a href="#" title="Facebook">f</a>
                    <a href="#" title="Twitter">𝕏</a>
                    <a href="#" title="LinkedIn">in</a>
                </div>
            </div>
            
            <div class="footer-section">
                <h4>Navigation</h4>
                <ul>
                    <li><a href="/LIBRARYMANGEMENTSYSTEM/index.php">Dashboard</a></li>
                    <li><a href="/LIBRARYMANGEMENTSYSTEM/books/search.php">Search Books</a></li>
                    <li><a href="/LIBRARYMANGEMENTSYSTEM/books/list.php">All Books</a></li>
                    <li><a href="/LIBRARYMANGEMENTSYSTEM/members/list.php">Members</a></li>
                    <li><a href="/LIBRARYMANGEMENTSYSTEM/loans/list.php">Loans</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h4>Support & Info</h4>
                <ul>
                    <li><a href="mailto:admin@library.edu">📧 Contact Admin</a></li>
                    <li><a href="#">📖 Documentation</a></li>
                    <li><a href="#">❓ FAQ</a></li>
                    <li><a href="#">🔒 Privacy Policy</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h4>System Info</h4>
                <p><strong>Version:</strong> 1.0.0</p>
                <p><strong>Last Updated:</strong> <?php echo date('M d, Y'); ?></p>
                <p><strong>Status:</strong> <span class="status-active">● Online</span></p>
            </div>
        </div>
        
        <div class="footer-divider"></div>
        
        <div class="footer-bottom">
            <div class="footer-bottom-content">
                <p>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?>. All rights reserved.</p>
                <p>🔒 Secured against XSS and SQL Injection</p>
            </div>
        </div>
    </div>
</footer>