<?php
/**
 * Edit Member
 */

require_once '../config/config.php';
require_once '../models/Member.php';

Security::requireLogin();

$memberModel = new Member();
$error = '';
$memberId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($memberId <= 0) {
    $_SESSION['error_message'] = 'Invalid member ID.';
    header('Location: list.php');
    exit;
}

$member = $memberModel->getById($memberId);

if (!$member) {
    $_SESSION['error_message'] = 'Member not found.';
    header('Location: list.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !Security::verifyCSRFToken($_POST['csrf_token'])) {
        $error = 'Invalid security token. Please try again.';
    } else {
        $data = [
            'first_name' => Security::sanitizeInput($_POST['first_name'] ?? ''),
            'last_name' => Security::sanitizeInput($_POST['last_name'] ?? ''),
            'email' => Security::sanitizeInput($_POST['email'] ?? ''),
            'phone' => Security::sanitizeInput($_POST['phone'] ?? ''),
            'address' => Security::sanitizeInput($_POST['address'] ?? ''),
            'membership_type' => Security::sanitizeInput($_POST['membership_type'] ?? 'public'),
            'status' => Security::sanitizeInput($_POST['status'] ?? 'active')
        ];
        
        if (empty($data['first_name']) || empty($data['last_name']) || empty($data['email'])) {
            $error = 'First name, last name, and email are required fields.';
        } elseif (!Security::validateEmail($data['email'])) {
            $error = 'Please enter a valid email address.';
        } elseif ($memberModel->emailExists($data['email'], $memberId)) {
            $error = 'A member with this email already exists.';
        } else {
            try {
                if ($memberModel->update($memberId, $data)) {
                    $_SESSION['success_message'] = 'Member updated successfully!';
                    header('Location: view.php?id=' . $memberId);
                    exit;
                } else {
                    $error = 'Failed to update member. Please try again.';
                }
            } catch (Exception $e) {
                error_log('Update member error: ' . $e->getMessage());
                $error = 'An error occurred while updating the member.';
            }
        }
    }
} else {
    $data = $member;
}

$csrfToken = Security::generateCSRFToken();
$pageTitle = 'Edit Member';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle . ' - ' . APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1><?php echo $pageTitle; ?>: <?php echo Security::sanitizeInput($member['first_name'] . ' ' . $member['last_name']); ?></h1>
            <a href="list.php" class="btn btn-secondary">← Back to List</a>
        </div>
        
        <?php if ($error): ?>
        <div class="alert alert-danger">
            <?php echo $error; ?>
        </div>
        <?php endif; ?>
        
        <div class="form-container">
            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="first_name">First Name <span class="required">*</span></label>
                        <input type="text" id="first_name" name="first_name" class="form-control" value="<?php echo $data['first_name']; ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="last_name">Last Name <span class="required">*</span></label>
                        <input type="text" id="last_name" name="last_name" class="form-control" value="<?php echo $data['last_name']; ?>" required>
                    </div>
                    
                    <div class="form-group full-width">
                        <label for="email">Email <span class="required">*</span></label>
                        <input type="email" id="email" name="email" class="form-control" value="<?php echo $data['email']; ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input type="tel" id="phone" name="phone" class="form-control" value="<?php echo $data['phone'] ?? ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="membership_type">Membership Type</label>
                        <select id="membership_type" name="membership_type" class="form-control">
                            <option value="public" <?php echo $data['membership_type'] === 'public' ? 'selected' : ''; ?>>Public</option>
                            <option value="student" <?php echo $data['membership_type'] === 'student' ? 'selected' : ''; ?>>Student</option>
                            <option value="faculty" <?php echo $data['membership_type'] === 'faculty' ? 'selected' : ''; ?>>Faculty</option>
                        </select>
                    </div>
                    
                    <div class="form-group full-width">
                        <label for="address">Address</label>
                        <textarea id="address" name="address" class="form-control" rows="3"><?php echo $data['address'] ?? ''; ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select id="status" name="status" class="form-control">
                            <option value="active" <?php echo $data['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="suspended" <?php echo $data['status'] === 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                            <option value="expired" <?php echo $data['status'] === 'expired' ? 'selected' : ''; ?>>Expired</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-success">Update Member</button>
                    <a href="list.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>
