<?php
/**
 * Add New Member
 */

require_once '../config/config.php';
require_once '../models/Member.php';

Security::requireLogin();

$memberModel = new Member();
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !Security::verifyCSRFToken($_POST['csrf_token'])) {
        $error = 'Invalid security token. Please try again.';
    } else {
        $data = [
            'first_name' => Security::sanitizeInput($_POST['first_name'] ?? ''),
            'last_name' => Security::sanitizeInput($_POST['last_name'] ?? ''),
            'email' => Security::sanitizeInput($_POST['email'] ?? ''),
            'phone' => Security::sanitizeInput($_POST['phone'] ?? ''),
            'address' => Security::sanitizeInput($_POST['address'] ?? ''),
            'membership_type' => Security::sanitizeInput($_POST['membership_type'] ?? 'public'),
            'membership_date' => Security::sanitizeInput($_POST['membership_date'] ?? date('Y-m-d')),
            'status' => Security::sanitizeInput($_POST['status'] ?? 'active')
        ];
        
        // Validation
        if (empty($data['first_name']) || empty($data['last_name']) || empty($data['email'])) {
            $error = 'First name, last name, and email are required fields.';
        } elseif (!Security::validateEmail($data['email'])) {
            $error = 'Please enter a valid email address.';
        } elseif ($memberModel->emailExists($data['email'])) {
            $error = 'A member with this email already exists.';
        } else {
            try {
                if ($memberModel->create($data)) {
                    $_SESSION['success_message'] = 'Member added successfully!';
                    header('Location: list.php');
                    exit;
                } else {
                    $error = 'Failed to add member. Please try again.';
                }
            } catch (Exception $e) {
                error_log('Add member error: ' . $e->getMessage());
                $error = 'An error occurred while adding the member.';
            }
        }
    }
}

$csrfToken = Security::generateCSRFToken();
$pageTitle = 'Add New Member';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle . ' - ' . APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1><?php echo $pageTitle; ?></h1>
            <a href="list.php" class="btn btn-secondary">← Back to List</a>
        </div>
        
        <?php if ($error): ?>
        <div class="alert alert-danger">
            <?php echo $error; ?>
        </div>
        <?php endif; ?>
        
        <div class="form-container">
            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="first_name">First Name <span class="required">*</span></label>
                        <input type="text" id="first_name" name="first_name" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="last_name">Last Name <span class="required">*</span></label>
                        <input type="text" id="last_name" name="last_name" class="form-control" required>
                    </div>
                    
                    <div class="form-group full-width">
                        <label for="email">Email <span class="required">*</span></label>
                        <input type="email" id="email" name="email" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input type="tel" id="phone" name="phone" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label for="membership_type">Membership Type</label>
                        <select id="membership_type" name="membership_type" class="form-control">
                            <option value="public">Public</option>
                            <option value="student">Student</option>
                            <option value="faculty">Faculty</option>
                        </select>
                    </div>
                    
                    <div class="form-group full-width">
                        <label for="address">Address</label>
                        <textarea id="address" name="address" class="form-control" rows="3"></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="membership_date">Membership Date</label>
                        <input type="date" id="membership_date" name="membership_date" class="form-control" value="<?php echo date('Y-m-d'); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select id="status" name="status" class="form-control">
                            <option value="active">Active</option>
                            <option value="suspended">Suspended</option>
                            <option value="expired">Expired</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-success">Add Member</button>
                    <a href="list.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>
