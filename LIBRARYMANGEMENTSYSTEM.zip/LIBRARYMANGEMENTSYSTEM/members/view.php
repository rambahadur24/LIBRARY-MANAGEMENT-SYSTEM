<?php
/**
 * View Member Details
 */

require_once '../config/config.php';
require_once '../models/Member.php';
require_once '../models/Loan.php';

Security::requireLogin();

$memberModel = new Member();
$loanModel = new Loan();

$memberId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($memberId <= 0) {
    $_SESSION['error_message'] = 'Invalid member ID.';
    header('Location: list.php');
    exit;
}

$member = $memberModel->getWithLoans($memberId);

if (!$member) {
    $_SESSION['error_message'] = 'Member not found.';
    header('Location: list.php');
    exit;
}

$successMessage = $_SESSION['success_message'] ?? '';
$errorMessage = $_SESSION['error_message'] ?? '';
unset($_SESSION['success_message']);
unset($_SESSION['error_message']);

$pageTitle = 'Member Details';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle . ' - ' . APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1><?php echo Security::sanitizeInput($member['first_name'] . ' ' . $member['last_name']); ?></h1>
            <div class="header-actions">
                <a href="edit.php?id=<?php echo $member['member_id']; ?>" class="btn btn-warning">Edit</a>
                <a href="list.php" class="btn btn-secondary">← Back to List</a>
            </div>
        </div>
        
        <?php if ($successMessage): ?>
        <div class="alert alert-success">
            <?php echo $successMessage; ?>
        </div>
        <?php endif; ?>
        
        <?php if ($errorMessage): ?>
        <div class="alert alert-danger">
            <?php echo $errorMessage; ?>
        </div>
        <?php endif; ?>
        
        <div class="member-details">
            <div class="details-grid">
                <div class="detail-group">
                    <label>Email</label>
                    <p class="detail-value"><a href="mailto:<?php echo $member['email']; ?>"><?php echo Security::sanitizeInput($member['email']); ?></a></p>
                </div>
                
                <div class="detail-group">
                    <label>Phone</label>
                    <p class="detail-value"><?php echo Security::sanitizeInput($member['phone'] ?? 'N/A'); ?></p>
                </div>
                
                <div class="detail-group">
                    <label>Membership Type</label>
                    <p class="detail-value">
                        <span class="badge badge-<?php echo $member['membership_type'] === 'student' ? 'primary' : ($member['membership_type'] === 'faculty' ? 'info' : 'secondary'); ?>">
                            <?php echo ucfirst($member['membership_type']); ?>
                        </span>
                    </p>
                </div>
                
                <div class="detail-group">
                    <label>Status</label>
                    <p class="detail-value">
                        <span class="badge badge-<?php echo $member['status'] === 'active' ? 'success' : ($member['status'] === 'suspended' ? 'danger' : 'warning'); ?>">
                            <?php echo ucfirst($member['status']); ?>
                        </span>
                    </p>
                </div>
                
                <div class="detail-group full-width">
                    <label>Address</label>
                    <p class="detail-value"><?php echo Security::sanitizeInput($member['address'] ?? 'N/A'); ?></p>
                </div>
                
                <div class="detail-group">
                    <label>Join Date</label>
                    <p class="detail-value"><?php echo date('M d, Y', strtotime($member['membership_date'])); ?></p>
                </div>
            </div>
            
            <?php if (!empty($member['active_loans'])): ?>
            <div class="active-loans-section">
                <h3>Active Loans</h3>
                <div class="table-container">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Book Title</th>
                                <th>ISBN</th>
                                <th>Loan Date</th>
                                <th>Due Date</th>
                                <th>Days Left</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($member['active_loans'] as $loan): ?>
                            <tr>
                                <td><?php echo Security::sanitizeInput($loan['title']); ?></td>
                                <td><code><?php echo Security::sanitizeInput($loan['isbn']); ?></code></td>
                                <td><?php echo date('M d, Y', strtotime($loan['loan_date'])); ?></td>
                                <td><?php echo date('M d, Y', strtotime($loan['due_date'])); ?></td>
                                <td>
                                    <?php 
                                        $daysLeft = ceil((strtotime($loan['due_date']) - time()) / (60 * 60 * 24));
                                        $badgeClass = $daysLeft > 3 ? 'success' : ($daysLeft > 0 ? 'warning' : 'danger');
                                    ?>
                                    <span class="badge badge-<?php echo $badgeClass; ?>"><?php echo $daysLeft; ?></span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php else: ?>
            <div class="alert alert-info">
                No active loans for this member.
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>
