<?php
/**
 * Delete Member
 */

require_once '../config/config.php';
require_once '../models/Member.php';

Security::requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error_message'] = 'Invalid request method.';
    header('Location: list.php');
    exit;
}

if (!isset($_POST['csrf_token']) || !Security::verifyCSRFToken($_POST['csrf_token'])) {
    $_SESSION['error_message'] = 'Invalid security token. Please try again.';
    header('Location: list.php');
    exit;
}

$memberId = isset($_POST['member_id']) ? intval($_POST['member_id']) : 0;

if ($memberId <= 0) {
    $_SESSION['error_message'] = 'Invalid member ID.';
    header('Location: list.php');
    exit;
}

$memberModel = new Member();
$member = $memberModel->getById($memberId);

if (!$member) {
    $_SESSION['error_message'] = 'Member not found.';
    header('Location: list.php');
    exit;
}

try {
    if ($memberModel->delete($memberId)) {
        $_SESSION['success_message'] = 'Member "' . Security::sanitizeInput($member['first_name'] . ' ' . $member['last_name']) . '" deleted successfully!';
    } else {
        $_SESSION['error_message'] = 'Cannot delete member. They may have active loans.';
    }
} catch (Exception $e) {
    error_log('Delete member error: ' . $e->getMessage());
    $_SESSION['error_message'] = 'An error occurred while deleting the member.';
}

header('Location: list.php');
exit;
?>
