<?php
/**
 * Member Model - Handles all member-related database operations
 */

require_once __DIR__ . '/../config/config.php';

class Member {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    /**
     * Get all members with pagination
     */
    public function getAll($page = 1, $limit = ITEMS_PER_PAGE, $status = null) {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT * FROM members WHERE 1=1";
        $params = [];
        
        if ($status !== null) {
            $sql .= " AND status = :status";
            $params[':status'] = $status;
        }
        
        $sql .= " ORDER BY last_name, first_name ASC LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    /**
     * Get total count of members
     */
    public function getCount($searchParams = [], $status = null) {
        $sql = "SELECT COUNT(*) as total FROM members WHERE 1=1";
        $params = [];
        
        if ($status !== null) {
            $sql .= " AND status = :status";
            $params[':status'] = $status;
        }
        
        if (!empty($searchParams['name'])) {
            $sql .= " AND (first_name LIKE :name OR last_name LIKE :name)";
            $params[':name'] = '%' . $searchParams['name'] . '%';
        }
        
        if (!empty($searchParams['email'])) {
            $sql .= " AND email LIKE :email";
            $params[':email'] = '%' . $searchParams['email'] . '%';
        }
        
        if (!empty($searchParams['membership_type'])) {
            $sql .= " AND membership_type = :type";
            $params[':type'] = $searchParams['membership_type'];
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch();
        
        return $result['total'];
    }
    
    /**
     * Get member by ID
     */
    public function getById($id) {
        $stmt = $this->db->prepare("SELECT * FROM members WHERE member_id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetch();
    }
    
    /**
     * Search members
     */
    public function search($params, $page = 1, $limit = ITEMS_PER_PAGE) {
        $offset = ($page - 1) * $limit;
        $sql = "SELECT * FROM members WHERE 1=1";
        $bindParams = [];
        
        if (!empty($params['name'])) {
            $sql .= " AND (first_name LIKE :name OR last_name LIKE :name)";
            $bindParams[':name'] = '%' . $params['name'] . '%';
        }
        
        if (!empty($params['email'])) {
            $sql .= " AND email LIKE :email";
            $bindParams[':email'] = '%' . $params['email'] . '%';
        }
        
        if (!empty($params['phone'])) {
            $sql .= " AND phone LIKE :phone";
            $bindParams[':phone'] = '%' . $params['phone'] . '%';
        }
        
        if (!empty($params['membership_type'])) {
            $sql .= " AND membership_type = :type";
            $bindParams[':type'] = $params['membership_type'];
        }
        
        if (!empty($params['status'])) {
            $sql .= " AND status = :status";
            $bindParams[':status'] = $params['status'];
        }
        
        $sql .= " ORDER BY last_name, first_name ASC LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($sql);
        
        foreach ($bindParams as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
    
    /**
     * Create new member
     */
    public function create($data) {
        $sql = "INSERT INTO members (first_name, last_name, email, phone, address, 
                membership_date, membership_type, status) 
                VALUES (:first_name, :last_name, :email, :phone, :address, 
                :membership_date, :membership_type, :status)";
        
        $stmt = $this->db->prepare($sql);
        
        return $stmt->execute([
            ':first_name' => $data['first_name'],
            ':last_name' => $data['last_name'],
            ':email' => $data['email'],
            ':phone' => $data['phone'] ?? null,
            ':address' => $data['address'] ?? null,
            ':membership_date' => $data['membership_date'] ?? date('Y-m-d'),
            ':membership_type' => $data['membership_type'] ?? 'public',
            ':status' => $data['status'] ?? 'active'
        ]);
    }
    
    /**
     * Update member
     */
    public function update($id, $data) {
        $sql = "UPDATE members SET 
                first_name = :first_name,
                last_name = :last_name,
                email = :email,
                phone = :phone,
                address = :address,
                membership_type = :membership_type,
                status = :status
                WHERE member_id = :id";
        
        $stmt = $this->db->prepare($sql);
        
        return $stmt->execute([
            ':id' => $id,
            ':first_name' => $data['first_name'],
            ':last_name' => $data['last_name'],
            ':email' => $data['email'],
            ':phone' => $data['phone'] ?? null,
            ':address' => $data['address'] ?? null,
            ':membership_type' => $data['membership_type'] ?? 'public',
            ':status' => $data['status'] ?? 'active'
        ]);
    }
    
    /**
     * Delete member
     */
    public function delete($id) {
        // Check if member has active loans
        $stmt = $this->db->prepare("
            SELECT COUNT(*) as loan_count 
            FROM loans 
            WHERE member_id = :id AND status = 'active'
        ");
        $stmt->execute([':id' => $id]);
        $result = $stmt->fetch();
        
        if ($result['loan_count'] > 0) {
            return false; // Cannot delete member with active loans
        }
        
        $stmt = $this->db->prepare("DELETE FROM members WHERE member_id = :id");
        return $stmt->execute([':id' => $id]);
    }
    
    /**
     * Check if email already exists
     */
    public function emailExists($email, $excludeId = null) {
        $sql = "SELECT COUNT(*) FROM members WHERE email = :email";
        $params = [':email' => $email];
        
        if ($excludeId !== null) {
            $sql .= " AND member_id != :id";
            $params[':id'] = $excludeId;
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        
        return $stmt->fetchColumn() > 0;
    }
    
    /**
     * Get member with active loans
     */
    public function getWithLoans($memberId) {
        $member = $this->getById($memberId);
        
        if ($member) {
            $stmt = $this->db->prepare("
                SELECT l.*, b.title, b.isbn 
                FROM loans l 
                JOIN books b ON l.book_id = b.book_id 
                WHERE l.member_id = :id AND l.status = 'active'
                ORDER BY l.due_date ASC
            ");
            $stmt->execute([':id' => $memberId]);
            $member['active_loans'] = $stmt->fetchAll();
        }
        
        return $member;
    }
}
?>
