<?php
/**
 * Loan Model - Handles all loan-related database operations
 */

require_once __DIR__ . '/../config/config.php';

class Loan {
    private $db;
    private $loanDays = 14; // Default loan period in days
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    /**
     * Get all loans with pagination
     */
    public function getAll($page = 1, $limit = ITEMS_PER_PAGE, $status = null) {
        $offset = ($page - 1) * $limit;
        
        $sql = "SELECT l.*, b.title, b.isbn, m.first_name, m.last_name, m.email 
                FROM loans l 
                JOIN books b ON l.book_id = b.book_id 
                JOIN members m ON l.member_id = m.member_id 
                WHERE 1=1";
        
        $params = [];
        
        if ($status !== null) {
            $sql .= " AND l.status = :status";
            $params[':status'] = $status;
        }
        
        $sql .= " ORDER BY l.due_date ASC LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    /**
     * Get total count of loans
     */
    public function getCount($status = null) {
        $sql = "SELECT COUNT(*) as total FROM loans WHERE 1=1";
        $params = [];
        
        if ($status !== null) {
            $sql .= " AND status = :status";
            $params[':status'] = $status;
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch();
        
        return $result['total'];
    }
    
    /**
     * Get loan by ID
     */
    public function getById($id) {
        $stmt = $this->db->prepare("
            SELECT l.*, b.title, b.isbn, m.first_name, m.last_name, m.email 
            FROM loans l 
            JOIN books b ON l.book_id = b.book_id 
            JOIN members m ON l.member_id = m.member_id 
            WHERE l.loan_id = :id
        ");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetch();
    }
    
    /**
     * Issue a new loan
     */
    public function issueLoan($bookId, $memberId, $loanDays = null) {
        if ($loanDays === null) {
            $loanDays = $this->loanDays;
        }
        
        try {
            $this->db->beginTransaction();
            
            // Check if book is available
            $stmt = $this->db->prepare("
                SELECT copies_available FROM books WHERE book_id = :id
            ");
            $stmt->execute([':id' => $bookId]);
            $book = $stmt->fetch();
            
            if (!$book || $book['copies_available'] <= 0) {
                return false;
            }
            
            // Create loan record
            $loanDate = date('Y-m-d');
            $dueDate = date('Y-m-d', strtotime("+$loanDays days"));
            
            $stmt = $this->db->prepare("
                INSERT INTO loans (book_id, member_id, loan_date, due_date, status) 
                VALUES (:book_id, :member_id, :loan_date, :due_date, 'active')
            ");
            
            $stmt->execute([
                ':book_id' => $bookId,
                ':member_id' => $memberId,
                ':loan_date' => $loanDate,
                ':due_date' => $dueDate
            ]);
            
            // Update book availability
            $stmt = $this->db->prepare("
                UPDATE books SET copies_available = copies_available - 1 
                WHERE book_id = :id
            ");
            $stmt->execute([':id' => $bookId]);
            
            $this->db->commit();
            return true;
            
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log('Loan issuance error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Return a book
     */
    public function returnBook($loanId, $fineAmount = 0) {
        try {
            $this->db->beginTransaction();
            
            // Get loan details
            $stmt = $this->db->prepare("SELECT book_id, status FROM loans WHERE loan_id = :id");
            $stmt->execute([':id' => $loanId]);
            $loan = $stmt->fetch();
            
            if (!$loan || $loan['status'] !== 'active') {
                return false;
            }
            
            // Update loan record
            $stmt = $this->db->prepare("
                UPDATE loans 
                SET return_date = CURDATE(), status = 'returned', fine_amount = :fine 
                WHERE loan_id = :id
            ");
            
            $stmt->execute([
                ':id' => $loanId,
                ':fine' => $fineAmount
            ]);
            
            // Update book availability
            $stmt = $this->db->prepare("
                UPDATE books SET copies_available = copies_available + 1 
                WHERE book_id = :id
            ");
            $stmt->execute([':id' => $loan['book_id']]);
            
            $this->db->commit();
            return true;
            
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log('Book return error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get overdue loans
     */
    public function getOverdueLoans() {
        $stmt = $this->db->prepare("
            SELECT l.*, b.title, b.isbn, m.first_name, m.last_name, m.email,
                   DATEDIFF(CURDATE(), l.due_date) as days_overdue
            FROM loans l 
            JOIN books b ON l.book_id = b.book_id 
            JOIN members m ON l.member_id = m.member_id 
            WHERE l.status = 'active' AND l.due_date < CURDATE()
            ORDER BY l.due_date ASC
        ");
        
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    /**
     * Calculate fine for overdue books
     */
    public function calculateFine($loanId, $finePerDay = 0.50) {
        $stmt = $this->db->prepare("
            SELECT due_date FROM loans WHERE loan_id = :id AND status = 'active'
        ");
        $stmt->execute([':id' => $loanId]);
        $loan = $stmt->fetch();
        
        if (!$loan) {
            return 0;
        }
        
        $dueDate = strtotime($loan['due_date']);
        $today = strtotime(date('Y-m-d'));
        
        if ($today > $dueDate) {
            $daysOverdue = floor(($today - $dueDate) / (60 * 60 * 24));
            return $daysOverdue * $finePerDay;
        }
        
        return 0;
    }
    
    /**
     * Get member's active loans
     */
    public function getMemberLoans($memberId, $status = 'active') {
        $sql = "
            SELECT l.*, b.title, b.isbn 
            FROM loans l 
            JOIN books b ON l.book_id = b.book_id 
            WHERE l.member_id = :member_id";
        
        $params = [':member_id' => $memberId];
        
        if ($status !== null) {
            $sql .= " AND l.status = :status";
            $params[':status'] = $status;
        }
        
        $sql .= " ORDER BY l.due_date ASC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        
        return $stmt->fetchAll();
    }
    
    /**
     * Get book's loan history
     */
    public function getBookLoans($bookId) {
        $stmt = $this->db->prepare("
            SELECT l.*, m.first_name, m.last_name, m.email 
            FROM loans l 
            JOIN members m ON l.member_id = m.member_id 
            WHERE l.book_id = :id
            ORDER BY l.loan_date DESC
        ");
        $stmt->execute([':id' => $bookId]);
        
        return $stmt->fetchAll();
    }
    
    /**
     * Update loan due date
     */
    public function updateDueDate($loanId, $newDueDate) {
        $stmt = $this->db->prepare("
            UPDATE loans SET due_date = :due_date WHERE loan_id = :id AND status = 'active'
        ");
        
        return $stmt->execute([
            ':id' => $loanId,
            ':due_date' => $newDueDate
        ]);
    }
}
?>
