<?php
/**
 * Book Model - Handles all book-related database operations
 */

require_once __DIR__ . '/../config/config.php';

class Book {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    /**
     * Get all books with pagination
     */
    public function getAll($page = 1, $limit = ITEMS_PER_PAGE) {
        $offset = ($page - 1) * $limit;
        
        $stmt = $this->db->prepare("
            SELECT * FROM books 
            ORDER BY title ASC 
            LIMIT :limit OFFSET :offset
        ");
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
    
    /**
     * Get total count of books
     */
    public function getCount($searchParams = []) {
        $sql = "SELECT COUNT(*) as total FROM books WHERE 1=1";
        $params = [];
        
        if (!empty($searchParams['title'])) {
            $sql .= " AND title LIKE :title";
            $params[':title'] = '%' . $searchParams['title'] . '%';
        }
        
        if (!empty($searchParams['author'])) {
            $sql .= " AND author LIKE :author";
            $params[':author'] = '%' . $searchParams['author'] . '%';
        }
        
        if (!empty($searchParams['genre'])) {
            $sql .= " AND genre = :genre";
            $params[':genre'] = $searchParams['genre'];
        }
        
        if (!empty($searchParams['year'])) {
            $sql .= " AND publication_year = :year";
            $params[':year'] = $searchParams['year'];
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch();
        
        return $result['total'];
    }
    
    /**
     * Get book by ID
     */
    public function getById($id) {
        $stmt = $this->db->prepare("SELECT * FROM books WHERE book_id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetch();
    }
    
    /**
     * Advanced search with multiple criteria
     */
    public function search($params, $page = 1, $limit = ITEMS_PER_PAGE) {
        $offset = ($page - 1) * $limit;
        $sql = "SELECT * FROM books WHERE 1=1";
        $bindParams = [];
        
        if (!empty($params['title'])) {
            $sql .= " AND title LIKE :title";
            $bindParams[':title'] = '%' . $params['title'] . '%';
        }
        
        if (!empty($params['author'])) {
            $sql .= " AND author LIKE :author";
            $bindParams[':author'] = '%' . $params['author'] . '%';
        }
        
        if (!empty($params['isbn'])) {
            $sql .= " AND isbn LIKE :isbn";
            $bindParams[':isbn'] = '%' . $params['isbn'] . '%';
        }
        
        if (!empty($params['genre'])) {
            $sql .= " AND genre = :genre";
            $bindParams[':genre'] = $params['genre'];
        }
        
        if (!empty($params['publisher'])) {
            $sql .= " AND publisher LIKE :publisher";
            $bindParams[':publisher'] = '%' . $params['publisher'] . '%';
        }
        
        if (!empty($params['year'])) {
            $sql .= " AND publication_year = :year";
            $bindParams[':year'] = $params['year'];
        }
        
        if (!empty($params['year_from'])) {
            $sql .= " AND publication_year >= :year_from";
            $bindParams[':year_from'] = $params['year_from'];
        }
        
        if (!empty($params['year_to'])) {
            $sql .= " AND publication_year <= :year_to";
            $bindParams[':year_to'] = $params['year_to'];
        }
        
        if (isset($params['available']) && $params['available'] === '1') {
            $sql .= " AND copies_available > 0";
        }
        
        $sql .= " ORDER BY title ASC LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($sql);
        
        foreach ($bindParams as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
    
    /**
     * Create new book
     */
    public function create($data) {
        // Ensure copies is at least 1
        $copies = !empty($data['copies']) ? intval($data['copies']) : 1;
        
        $sql = "INSERT INTO books (isbn, title, author, publisher, publication_year, 
                genre, pages, copies_available, total_copies, description) 
                VALUES (:isbn, :title, :author, :publisher, :year, :genre, :pages, 
                :copies_available, :total_copies, :description)";
        
        try {
            $stmt = $this->db->prepare($sql);
            
            $result = $stmt->execute([
                ':isbn' => trim($data['isbn']),
                ':title' => trim($data['title']),
                ':author' => trim($data['author']),
                ':publisher' => !empty($data['publisher']) ? trim($data['publisher']) : null,
                ':year' => !empty($data['publication_year']) ? intval($data['publication_year']) : null,
                ':genre' => !empty($data['genre']) ? trim($data['genre']) : null,
                ':pages' => !empty($data['pages']) ? intval($data['pages']) : null,
                ':copies_available' => $copies,
                ':total_copies' => $copies,
                ':description' => !empty($data['description']) ? trim($data['description']) : null
            ]);
            
            return $result;
        } catch (PDOException $e) {
            error_log('Book creation error: ' . $e->getMessage());
            throw new Exception('Failed to create book: ' . $e->getMessage());
        }
    }
    
    /**
     * Update book
     */
    public function update($id, $data) {
        $sql = "UPDATE books SET 
                isbn = :isbn,
                title = :title,
                author = :author,
                publisher = :publisher,
                publication_year = :year,
                genre = :genre,
                pages = :pages,
                total_copies = :total,
                copies_available = :available,
                description = :description
                WHERE book_id = :id";
        
        $stmt = $this->db->prepare($sql);
        
        return $stmt->execute([
            ':id' => $id,
            ':isbn' => $data['isbn'],
            ':title' => $data['title'],
            ':author' => $data['author'],
            ':publisher' => $data['publisher'] ?? null,
            ':year' => $data['publication_year'] ?? null,
            ':genre' => $data['genre'] ?? null,
            ':pages' => $data['pages'] ?? null,
            ':total' => $data['total_copies'] ?? 1,
            ':available' => $data['copies_available'] ?? 1,
            ':description' => $data['description'] ?? null
        ]);
    }
    
    /**
     * Delete book
     */
    public function delete($id) {
        // Check if book has active loans
        $stmt = $this->db->prepare("
            SELECT COUNT(*) as loan_count 
            FROM loans 
            WHERE book_id = :id AND status = 'active'
        ");
        $stmt->execute([':id' => $id]);
        $result = $stmt->fetch();
        
        if ($result['loan_count'] > 0) {
            return false; // Cannot delete book with active loans
        }
        
        $stmt = $this->db->prepare("DELETE FROM books WHERE book_id = :id");
        return $stmt->execute([':id' => $id]);
    }
    
    /**
     * Get all unique genres
     */
    public function getGenres() {
        $stmt = $this->db->query("
            SELECT DISTINCT genre 
            FROM books 
            WHERE genre IS NOT NULL 
            ORDER BY genre ASC
        ");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
    /**
     * Get all unique publication years
     */
    public function getYears() {
        $stmt = $this->db->query("
            SELECT DISTINCT publication_year 
            FROM books 
            WHERE publication_year IS NOT NULL 
            ORDER BY publication_year DESC
        ");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
    /**
     * Autocomplete search for AJAX
     */
    public function autocomplete($query, $field = 'title') {
        $allowedFields = ['title', 'author', 'isbn'];
        
        if (!in_array($field, $allowedFields)) {
            $field = 'title';
        }
        
        // Use proper query building
        $fieldName = $field;
        if ($field === 'title') {
            $sql = "SELECT DISTINCT title as value FROM books WHERE title LIKE :query LIMIT 10";
        } elseif ($field === 'author') {
            $sql = "SELECT DISTINCT author as value FROM books WHERE author LIKE :query LIMIT 10";
        } elseif ($field === 'isbn') {
            $sql = "SELECT DISTINCT isbn as value FROM books WHERE isbn LIKE :query LIMIT 10";
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':query' => $query . '%']);
        
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
    /**
     * Check if ISBN already exists
     */
    public function isbnExists($isbn, $excludeId = null) {
        $sql = "SELECT COUNT(*) FROM books WHERE isbn = :isbn";
        $params = [':isbn' => $isbn];
        
        if ($excludeId !== null) {
            $sql .= " AND book_id != :id";
            $params[':id'] = $excludeId;
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        
        return $stmt->fetchColumn() > 0;
    }
}
?>