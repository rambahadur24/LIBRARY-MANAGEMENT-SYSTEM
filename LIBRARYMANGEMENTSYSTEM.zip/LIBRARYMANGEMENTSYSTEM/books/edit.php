<?php
/**
 * Edit Book - CRUD Update Operation
 */

require_once '../config/config.php';
require_once '../models/Book.php';

Security::requireLogin();

$bookModel = new Book();
$genres = $bookModel->getGenres();
$error = '';
$bookId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($bookId <= 0) {
    $_SESSION['error_message'] = 'Invalid book ID.';
    header('Location: list.php');
    exit;
}

// Get book data
$book = $bookModel->getById($bookId);

if (!$book) {
    $_SESSION['error_message'] = 'Book not found.';
    header('Location: list.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    if (!isset($_POST['csrf_token']) || !Security::verifyCSRFToken($_POST['csrf_token'])) {
        $error = 'Invalid security token. Please try again.';
    } else {
        // Sanitize and validate input
        $genre = Security::sanitizeInput($_POST['genre'] ?? '');
        
        // If "other" genre selected or custom_genre provided, use the custom genre input
        if ($genre === 'other' || !empty($_POST['custom_genre'])) {
            $customGenre = Security::sanitizeInput($_POST['custom_genre'] ?? '');
            if (!empty($customGenre)) {
                $genre = $customGenre;
            }
        }
        
        $data = [
            'isbn' => Security::sanitizeInput($_POST['isbn'] ?? ''),
            'title' => Security::sanitizeInput($_POST['title'] ?? ''),
            'author' => Security::sanitizeInput($_POST['author'] ?? ''),
            'publisher' => Security::sanitizeInput($_POST['publisher'] ?? ''),
            'publication_year' => Security::sanitizeInput($_POST['publication_year'] ?? ''),
            'genre' => $genre,
            'pages' => Security::sanitizeInput($_POST['pages'] ?? ''),
            'total_copies' => Security::sanitizeInput($_POST['total_copies'] ?? 1),
            'copies_available' => Security::sanitizeInput($_POST['copies_available'] ?? 1),
            'description' => Security::sanitizeInput($_POST['description'] ?? '')
        ];
        
        // Validation
        if (empty($data['isbn']) || empty($data['title']) || empty($data['author'])) {
            $error = 'ISBN, Title, and Author are required fields.';
        } elseif ($bookModel->isbnExists($data['isbn'], $bookId)) {
            $error = 'A book with this ISBN already exists.';
        } elseif (!empty($data['publication_year']) && (!is_numeric($data['publication_year']) || $data['publication_year'] < 1000 || $data['publication_year'] > date('Y'))) {
            $error = 'Please enter a valid publication year.';
        } elseif (!empty($data['pages']) && (!is_numeric($data['pages']) || $data['pages'] < 1)) {
            $error = 'Please enter a valid number of pages.';
        } elseif (!is_numeric($data['total_copies']) || $data['total_copies'] < 1) {
            $error = 'Please enter a valid number of total copies.';
        } elseif (!is_numeric($data['copies_available']) || $data['copies_available'] < 0 || $data['copies_available'] > $data['total_copies']) {
            $error = 'Available copies must be between 0 and total copies.';
        } else {
            try {
                if ($bookModel->update($bookId, $data)) {
                    $_SESSION['success_message'] = 'Book updated successfully!';
                    header('Location: view.php?id=' . $bookId);
                    exit;
                } else {
                    $error = 'Failed to update book. Please try again.';
                }
            } catch (Exception $e) {
                error_log('Update book error: ' . $e->getMessage());
                $error = 'An error occurred while updating the book.';
            }
        }
    }
} else {
    // Populate form with existing data
    $data = $book;
}

$csrfToken = Security::generateCSRFToken();
$pageTitle = 'Edit Book';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle . ' - ' . APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1><?php echo $pageTitle; ?>: <?php echo Security::sanitizeInput($book['title']); ?></h1>
            <div>
                <a href="view.php?id=<?php echo $bookId; ?>" class="btn btn-info">
                    View Details
                </a>
                <a href="list.php" class="btn btn-secondary">
                    ← Back to List
                </a>
            </div>
        </div>
        
        <?php if ($error): ?>
        <div class="alert alert-danger">
            <?php echo $error; ?>
        </div>
        <?php endif; ?>
        
        <div class="form-container">
            <form method="POST" action="" id="editBookForm">
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                
                <div class="form-grid">
                    <!-- ISBN -->
                    <div class="form-group">
                        <label for="isbn">ISBN <span class="required">*</span></label>
                        <input type="text" 
                               id="isbn" 
                               name="isbn" 
                               class="form-control" 
                               required
                               value="<?php echo Security::sanitizeInput($data['isbn']); ?>">
                    </div>
                    
                    <!-- Title -->
                    <div class="form-group">
                        <label for="title">Title <span class="required">*</span></label>
                        <input type="text" 
                               id="title" 
                               name="title" 
                               class="form-control" 
                               required
                               value="<?php echo Security::sanitizeInput($data['title']); ?>">
                    </div>
                    
                    <!-- Author -->
                    <div class="form-group">
                        <label for="author">Author <span class="required">*</span></label>
                        <input type="text" 
                               id="author" 
                               name="author" 
                               class="form-control" 
                               required
                               value="<?php echo Security::sanitizeInput($data['author']); ?>">
                    </div>
                    
                    <!-- Publisher -->
                    <div class="form-group">
                        <label for="publisher">Publisher</label>
                        <input type="text" 
                               id="publisher" 
                               name="publisher" 
                               class="form-control"
                               value="<?php echo Security::sanitizeInput($data['publisher'] ?? ''); ?>">
                    </div>
                    
                    <!-- Genre -->
                    <div class="form-group">
                        <label for="genre">Genre</label>
                        <select id="genre" name="genre" class="form-control">
                            <option value="">Select Genre</option>
                            <?php foreach ($genres as $genre): ?>
                            <option value="<?php echo $genre; ?>" 
                                    <?php echo ($data['genre'] ?? '') === $genre ? 'selected' : ''; ?>>
                                <?php echo Security::sanitizeInput($genre); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Publication Year -->
                    <div class="form-group">
                        <label for="publication_year">Publication Year</label>
                        <input type="number" 
                               id="publication_year" 
                               name="publication_year" 
                               class="form-control"
                               min="1000"
                               max="<?php echo date('Y'); ?>"
                               value="<?php echo Security::sanitizeInput($data['publication_year'] ?? ''); ?>">
                    </div>
                    
                    <!-- Pages -->
                    <div class="form-group">
                        <label for="pages">Number of Pages</label>
                        <input type="number" 
                               id="pages" 
                               name="pages" 
                               class="form-control"
                               min="1"
                               value="<?php echo Security::sanitizeInput($data['pages'] ?? ''); ?>">
                    </div>
                    
                    <!-- Total Copies -->
                    <div class="form-group">
                        <label for="total_copies">Total Copies</label>
                        <input type="number" 
                               id="total_copies" 
                               name="total_copies" 
                               class="form-control"
                               min="1"
                               value="<?php echo Security::sanitizeInput($data['total_copies']); ?>">
                    </div>
                    
                    <!-- Available Copies -->
                    <div class="form-group">
                        <label for="copies_available">Available Copies</label>
                        <input type="number" 
                               id="copies_available" 
                               name="copies_available" 
                               class="form-control"
                               min="0"
                               value="<?php echo Security::sanitizeInput($data['copies_available']); ?>">
                        <small>Current loans: <?php echo $data['total_copies'] - $data['copies_available']; ?></small>
                    </div>
                </div>
                
                <!-- Description -->
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" 
                              name="description" 
                              class="form-control"
                              rows="4"><?php echo Security::sanitizeInput($data['description'] ?? ''); ?></textarea>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <span class="btn-icon">💾</span> Save Changes
                    </button>
                    <a href="view.php?id=<?php echo $bookId; ?>" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?>
    
    <script>
        // Show custom genre field when "Other" is selected
        document.getElementById('genre').addEventListener('change', function() {
            const customGroup = document.getElementById('customGenreGroup');
            const customInput = document.getElementById('custom_genre');
            
            if (this.value === 'other') {
                customGroup.style.display = 'block';
                customInput.required = true;
            } else {
                customGroup.style.display = 'none';
                customInput.required = false;
                customInput.value = ''; // Clear custom genre when not selecting "other"
            }
        });
        
        // Validate form before submission
        document.getElementById('editBookForm').addEventListener('submit', function(e) {
            const genreSelect = document.getElementById('genre');
            const customGenre = document.getElementById('custom_genre');
            
            // If "other" is selected, validate custom genre is filled
            if (genreSelect.value === 'other') {
                if (!customGenre.value.trim()) {
                    e.preventDefault();
                    alert('Please enter a custom genre name');
                    customGenre.focus();
                    return false;
                }
            }
        });
    </script>
    
    <style>
        .required { color: var(--danger-color); }
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }
        .page-header > div {
            display: flex;
            gap: 0.5rem;
        }
    </style>
</body>
</html>