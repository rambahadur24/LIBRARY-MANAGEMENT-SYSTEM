<?php
/**
 * Advanced Book Search with Multiple Criteria
 */

require_once '../config/config.php';
require_once '../models/Book.php';

Security::requireLogin();

$bookModel = new Book();
$genres = $bookModel->getGenres();
$years = $bookModel->getYears();

// Get search parameters
$searchParams = [];
if ($_SERVER['REQUEST_METHOD'] === 'GET' && !empty($_GET)) {
    $searchParams = [
        'title' => Security::sanitizeInput($_GET['title'] ?? ''),
        'author' => Security::sanitizeInput($_GET['author'] ?? ''),
        'isbn' => Security::sanitizeInput($_GET['isbn'] ?? ''),
        'genre' => Security::sanitizeInput($_GET['genre'] ?? ''),
        'publisher' => Security::sanitizeInput($_GET['publisher'] ?? ''),
        'year' => Security::sanitizeInput($_GET['year'] ?? ''),
        'year_from' => Security::sanitizeInput($_GET['year_from'] ?? ''),
        'year_to' => Security::sanitizeInput($_GET['year_to'] ?? ''),
        'available' => $_GET['available'] ?? ''
    ];
}

// Pagination
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$results = [];
$totalResults = 0;

if (!empty(array_filter($searchParams))) {
    $results = $bookModel->search($searchParams, $page);
    $totalResults = $bookModel->getCount($searchParams);
}

$totalPages = ceil($totalResults / ITEMS_PER_PAGE);
$pageTitle = 'Search Books';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle . ' - ' . APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container">
        <div class="search-page">
            <h1>Advanced Book Search</h1>
            
            <!-- Search Form -->
            <div class="search-form-container">
                <form method="GET" action="" class="search-form" id="searchForm">
                    <div class="form-grid">
                        <!-- Title Search with Autocomplete -->
                        <div class="form-group">
                            <label for="title">Title</label>
                            <input type="text" 
                                   id="title" 
                                   name="title" 
                                   class="form-control autocomplete" 
                                   data-field="title"
                                   value="<?php echo $searchParams['title'] ?? ''; ?>" 
                                   placeholder="Enter book title">
                            <div class="autocomplete-suggestions" id="title-suggestions"></div>
                        </div>
                        
                        <!-- Author Search with Autocomplete -->
                        <div class="form-group">
                            <label for="author">Author</label>
                            <input type="text" 
                                   id="author" 
                                   name="author" 
                                   class="form-control autocomplete" 
                                   data-field="author"
                                   value="<?php echo $searchParams['author'] ?? ''; ?>" 
                                   placeholder="Enter author name">
                            <div class="autocomplete-suggestions" id="author-suggestions"></div>
                        </div>
                        
                        <!-- ISBN Search -->
                        <div class="form-group">
                            <label for="isbn">ISBN</label>
                            <input type="text" 
                                   id="isbn" 
                                   name="isbn" 
                                   class="form-control" 
                                   value="<?php echo $searchParams['isbn'] ?? ''; ?>" 
                                   placeholder="Enter ISBN">
                        </div>
                        
                        <!-- Genre Filter -->
                        <div class="form-group">
                            <label for="genre">Genre</label>
                            <select id="genre" name="genre" class="form-control">
                                <option value="">All Genres</option>
                                <?php foreach ($genres as $genre): ?>
                                <option value="<?php echo $genre; ?>" 
                                        <?php echo ($searchParams['genre'] ?? '') === $genre ? 'selected' : ''; ?>>
                                    <?php echo Security::sanitizeInput($genre); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <!-- Publisher Search -->
                        <div class="form-group">
                            <label for="publisher">Publisher</label>
                            <input type="text" 
                                   id="publisher" 
                                   name="publisher" 
                                   class="form-control" 
                                   value="<?php echo $searchParams['publisher'] ?? ''; ?>" 
                                   placeholder="Enter publisher">
                        </div>
                        
                        <!-- Exact Year -->
                        <div class="form-group">
                            <label for="year">Publication Year</label>
                            <select id="year" name="year" class="form-control">
                                <option value="">Any Year</option>
                                <?php foreach ($years as $year): ?>
                                <option value="<?php echo $year; ?>" 
                                        <?php echo ($searchParams['year'] ?? '') == $year ? 'selected' : ''; ?>>
                                    <?php echo $year; ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <!-- Year Range From -->
                        <div class="form-group">
                            <label for="year_from">Year From</label>
                            <input type="number" 
                                   id="year_from" 
                                   name="year_from" 
                                   class="form-control" 
                                   min="1800" 
                                   max="<?php echo date('Y'); ?>"
                                   value="<?php echo $searchParams['year_from'] ?? ''; ?>" 
                                   placeholder="e.g., 2020">
                        </div>
                        
                        <!-- Year Range To -->
                        <div class="form-group">
                            <label for="year_to">Year To</label>
                            <input type="number" 
                                   id="year_to" 
                                   name="year_to" 
                                   class="form-control" 
                                   min="1800" 
                                   max="<?php echo date('Y'); ?>"
                                   value="<?php echo $searchParams['year_to'] ?? ''; ?>" 
                                   placeholder="e.g., 2024">
                        </div>
                        
                        <!-- Availability Filter -->
                        <div class="form-group">
                            <label for="available">Availability</label>
                            <select id="available" name="available" class="form-control">
                                <option value="">All Books</option>
                                <option value="1" <?php echo ($searchParams['available'] ?? '') === '1' ? 'selected' : ''; ?>>
                                    Available Only
                                </option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">
                            <span class="btn-icon">🔍</span> Search
                        </button>
                        <button type="button" class="btn btn-secondary" onclick="clearSearch()">
                            <span class="btn-icon">🔄</span> Clear
                        </button>
                    </div>
                </form>
            </div>
            
            <!-- Search Results -->
            <?php if (!empty(array_filter($searchParams))): ?>
            <div class="search-results">
                <div class="results-header">
                    <h2>Search Results</h2>
                    <p class="results-count">
                        Found <strong><?php echo $totalResults; ?></strong> book(s)
                    </p>
                </div>
                
                <?php if (!empty($results)): ?>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ISBN</th>
                                <th>Title</th>
                                <th>Author</th>
                                <th>Publisher</th>
                                <th>Genre</th>
                                <th>Year</th>
                                <th>Available</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($results as $book): ?>
                            <tr>
                                <td><?php echo Security::sanitizeInput($book['isbn']); ?></td>
                                <td><strong><?php echo Security::sanitizeInput($book['title']); ?></strong></td>
                                <td><?php echo Security::sanitizeInput($book['author']); ?></td>
                                <td><?php echo Security::sanitizeInput($book['publisher'] ?? 'N/A'); ?></td>
                                <td>
                                    <span class="badge badge-info">
                                        <?php echo Security::sanitizeInput($book['genre'] ?? 'N/A'); ?>
                                    </span>
                                </td>
                                <td><?php echo Security::sanitizeInput($book['publication_year'] ?? 'N/A'); ?></td>
                                <td>
                                    <span class="badge <?php echo $book['copies_available'] > 0 ? 'badge-success' : 'badge-danger'; ?>">
                                        <?php echo $book['copies_available']; ?>/<?php echo $book['total_copies']; ?>
                                    </span>
                                </td>
                                <td class="actions">
                                    <a href="view.php?id=<?php echo $book['book_id']; ?>" class="btn-sm btn-info">View</a>
                                    <a href="edit.php?id=<?php echo $book['book_id']; ?>" class="btn-sm btn-primary">Edit</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php
                    $queryString = http_build_query(array_merge($searchParams, ['page' => '']));
                    ?>
                    
                    <?php if ($page > 1): ?>
                    <a href="?<?php echo $queryString; ?>page=<?php echo $page - 1; ?>" class="page-link">« Previous</a>
                    <?php endif; ?>
                    
                    <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                    <a href="?<?php echo $queryString; ?>page=<?php echo $i; ?>" 
                       class="page-link <?php echo $i === $page ? 'active' : ''; ?>">
                        <?php echo $i; ?>
                    </a>
                    <?php endfor; ?>
                    
                    <?php if ($page < $totalPages): ?>
                    <a href="?<?php echo $queryString; ?>page=<?php echo $page + 1; ?>" class="page-link">Next »</a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                
                <?php else: ?>
                <div class="no-results">
                    <p>No books found matching your search criteria.</p>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?>
    
    <script src="../assets/js/autocomplete.js"></script>
    <script>
        function clearSearch() {
            window.location.href = 'search.php';
        }
    </script>
</body>
</html>