<?php
/**
 * Delete Book - CRUD Delete Operation
 * Security: Protected with CSRF token and confirmation
 */

require_once '../config/config.php';
require_once '../models/Book.php';

Security::requireLogin();

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error_message'] = 'Invalid request method.';
    header('Location: list.php');
    exit;
}

// Verify CSRF token
if (!isset($_POST['csrf_token']) || !Security::verifyCSRFToken($_POST['csrf_token'])) {
    $_SESSION['error_message'] = 'Invalid security token. Please try again.';
    header('Location: list.php');
    exit;
}

$bookId = isset($_POST['book_id']) ? intval($_POST['book_id']) : 0;

if ($bookId <= 0) {
    $_SESSION['error_message'] = 'Invalid book ID.';
    header('Location: list.php');
    exit;
}

$bookModel = new Book();

// Get book info before deletion
$book = $bookModel->getById($bookId);

if (!$book) {
    $_SESSION['error_message'] = 'Book not found.';
    header('Location: list.php');
    exit;
}

try {
    if ($bookModel->delete($bookId)) {
        $_SESSION['success_message'] = 'Book "' . Security::sanitizeInput($book['title']) . '" deleted successfully!';
    } else {
        $_SESSION['error_message'] = 'Cannot delete book. It may have active loans.';
    }
} catch (Exception $e) {
    error_log('Delete book error: ' . $e->getMessage());
    $_SESSION['error_message'] = 'An error occurred while deleting the book.';
}

header('Location: list.php');
exit;
?>