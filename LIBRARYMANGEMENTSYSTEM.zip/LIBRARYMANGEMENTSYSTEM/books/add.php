<?php
/**
 * Add New Book - CRUD Create Operation
 */

require_once '../config/config.php';
require_once '../models/Book.php';

Security::requireLogin();

$bookModel = new Book();
$genres = $bookModel->getGenres();
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    if (!isset($_POST['csrf_token']) || !Security::verifyCSRFToken($_POST['csrf_token'])) {
        $error = 'Invalid security token. Please try again.';
    } else {
        // Sanitize and validate input
        $genre = Security::sanitizeInput($_POST['genre'] ?? '');
        
        // If "other" genre selected or custom_genre provided, use the custom genre input
        if ($genre === 'other' || !empty($_POST['custom_genre'])) {
            $customGenre = Security::sanitizeInput($_POST['custom_genre'] ?? '');
            if (!empty($customGenre)) {
                $genre = $customGenre;
            }
        }
        
        $data = [
            'isbn' => Security::sanitizeInput($_POST['isbn'] ?? ''),
            'title' => Security::sanitizeInput($_POST['title'] ?? ''),
            'author' => Security::sanitizeInput($_POST['author'] ?? ''),
            'publisher' => Security::sanitizeInput($_POST['publisher'] ?? ''),
            'publication_year' => Security::sanitizeInput($_POST['publication_year'] ?? ''),
            'genre' => $genre,
            'pages' => Security::sanitizeInput($_POST['pages'] ?? ''),
            'copies' => Security::sanitizeInput($_POST['copies'] ?? 1),
            'description' => Security::sanitizeInput($_POST['description'] ?? '')
        ];
        
        // Validation
        if (empty($data['isbn']) || empty($data['title']) || empty($data['author'])) {
            $error = 'ISBN, Title, and Author are required fields.';
        } elseif ($bookModel->isbnExists($data['isbn'])) {
            $error = 'A book with this ISBN already exists.';
        } elseif (!empty($data['publication_year']) && (!is_numeric($data['publication_year']) || $data['publication_year'] < 1000 || $data['publication_year'] > date('Y'))) {
            $error = 'Please enter a valid publication year.';
        } elseif (!empty($data['pages']) && (!is_numeric($data['pages']) || $data['pages'] < 1)) {
            $error = 'Please enter a valid number of pages.';
        } elseif (!is_numeric($data['copies']) || $data['copies'] < 1) {
            $error = 'Please enter a valid number of copies.';
        } else {
            try {
                if ($bookModel->create($data)) {
                    $_SESSION['success_message'] = 'Book added successfully!';
                    header('Location: list.php');
                    exit;
                } else {
                    $error = 'Failed to add book. Please try again.';
                }
            } catch (Exception $e) {
                error_log('Add book error: ' . $e->getMessage());
                $error = 'Error: ' . $e->getMessage();
            }
        }
    }
}

$csrfToken = Security::generateCSRFToken();
$pageTitle = 'Add New Book';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle . ' - ' . APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1><?php echo $pageTitle; ?></h1>
            <a href="list.php" class="btn btn-secondary">
                ← Back to List
            </a>
        </div>
        
        <?php if ($error): ?>
        <div class="alert alert-danger">
            <?php echo $error; ?>
        </div>
        <?php endif; ?>
        
        <div class="form-container">
            <form method="POST" action="" id="addBookForm">
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                
                <div class="form-grid">
                    <!-- ISBN -->
                    <div class="form-group">
                        <label for="isbn">ISBN <span class="required">*</span></label>
                        <input type="text" 
                               id="isbn" 
                               name="isbn" 
                               class="form-control" 
                               required
                               value="<?php echo $data['isbn'] ?? ''; ?>"
                               placeholder="978-0-123456-78-9">
                    </div>
                    
                    <!-- Title -->
                    <div class="form-group">
                        <label for="title">Title <span class="required">*</span></label>
                        <input type="text" 
                               id="title" 
                               name="title" 
                               class="form-control" 
                               required
                               value="<?php echo $data['title'] ?? ''; ?>"
                               placeholder="Book title">
                    </div>
                    
                    <!-- Author -->
                    <div class="form-group">
                        <label for="author">Author <span class="required">*</span></label>
                        <input type="text" 
                               id="author" 
                               name="author" 
                               class="form-control" 
                               required
                               value="<?php echo $data['author'] ?? ''; ?>"
                               placeholder="Author name">
                    </div>
                    
                    <!-- Publisher -->
                    <div class="form-group">
                        <label for="publisher">Publisher</label>
                        <input type="text" 
                               id="publisher" 
                               name="publisher" 
                               class="form-control"
                               value="<?php echo $data['publisher'] ?? ''; ?>"
                               placeholder="Publisher name">
                    </div>
                    
                    <!-- Genre -->
                    <div class="form-group">
                        <label for="genre">Genre</label>
                        <select id="genre" name="genre" class="form-control">
                            <option value="">Select Genre</option>
                            <?php foreach ($genres as $genre): ?>
                            <option value="<?php echo $genre; ?>" 
                                    <?php echo (($data['genre'] ?? '') === $genre) ? 'selected' : ''; ?>>
                                <?php echo Security::sanitizeInput($genre); ?>
                            </option>
                            <?php endforeach; ?>
                            <option value="other">Other (Type Below)</option>
                        </select>
                    </div>
                    
                    <!-- Custom Genre -->
                    <div class="form-group" id="customGenreGroup" style="display:none;">
                        <label for="custom_genre">Custom Genre</label>
                        <input type="text" 
                               id="custom_genre" 
                               name="custom_genre" 
                               class="form-control"
                               placeholder="Enter genre name">
                    </div>
                    
                    <!-- Publication Year -->
                    <div class="form-group">
                        <label for="publication_year">Publication Year</label>
                        <input type="number" 
                               id="publication_year" 
                               name="publication_year" 
                               class="form-control"
                               min="1000"
                               max="<?php echo date('Y'); ?>"
                               value="<?php echo $data['publication_year'] ?? ''; ?>"
                               placeholder="<?php echo date('Y'); ?>">
                    </div>
                    
                    <!-- Pages -->
                    <div class="form-group">
                        <label for="pages">Number of Pages</label>
                        <input type="number" 
                               id="pages" 
                               name="pages" 
                               class="form-control"
                               min="1"
                               value="<?php echo $data['pages'] ?? ''; ?>"
                               placeholder="e.g., 350">
                    </div>
                    
                    <!-- Copies -->
                    <div class="form-group">
                        <label for="copies">Number of Copies</label>
                        <input type="number" 
                               id="copies" 
                               name="copies" 
                               class="form-control"
                               min="1"
                               value="<?php echo $data['copies'] ?? 1; ?>"
                               placeholder="1">
                    </div>
                </div>
                
                <!-- Description -->
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" 
                              name="description" 
                              class="form-control"
                              rows="4"
                              placeholder="Brief description of the book"><?php echo $data['description'] ?? ''; ?></textarea>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-success">
                        <span class="btn-icon">✓</span> Add Book
                    </button>
                    <a href="list.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?>
    
    <script>
        // Show custom genre field when "Other" is selected
        document.getElementById('genre').addEventListener('change', function() {
            const customGroup = document.getElementById('customGenreGroup');
            const customInput = document.getElementById('custom_genre');
            
            if (this.value === 'other') {
                customGroup.style.display = 'block';
                customInput.required = true;
            } else {
                customGroup.style.display = 'none';
                customInput.required = false;
                customInput.value = ''; // Clear custom genre when not selecting "other"
            }
        });
        
        // Validate form before submission
        document.getElementById('addBookForm').addEventListener('submit', function(e) {
            const genreSelect = document.getElementById('genre');
            const customGenre = document.getElementById('custom_genre');
            
            // If "other" is selected, validate custom genre is filled
            if (genreSelect.value === 'other') {
                if (!customGenre.value.trim()) {
                    e.preventDefault();
                    alert('Please enter a custom genre name');
                    customGenre.focus();
                    return false;
                }
            }
        });
    </script>
    
    <style>
        .required { color: var(--danger-color); }
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }
    </style>
</body>
</html>