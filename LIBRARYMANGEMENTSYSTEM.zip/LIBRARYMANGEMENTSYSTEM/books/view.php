<?php
/**
 * View Book Details
 */

require_once '../config/config.php';
require_once '../models/Book.php';
require_once '../models/Loan.php';

Security::requireLogin();

$bookModel = new Book();
$loanModel = new Loan();

$bookId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($bookId <= 0) {
    $_SESSION['error_message'] = 'Invalid book ID.';
    header('Location: list.php');
    exit;
}

// Get book details
$book = $bookModel->getById($bookId);

if (!$book) {
    $_SESSION['error_message'] = 'Book not found.';
    header('Location: list.php');
    exit;
}

// Get loan history
$loanHistory = $loanModel->getBookLoans($bookId);

// Handle success/error messages
$successMessage = $_SESSION['success_message'] ?? '';
$errorMessage = $_SESSION['error_message'] ?? '';
unset($_SESSION['success_message']);
unset($_SESSION['error_message']);

$pageTitle = 'Book Details';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle . ' - ' . APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1><?php echo Security::sanitizeInput($book['title']); ?></h1>
            <div class="header-actions">
                <a href="edit.php?id=<?php echo $book['book_id']; ?>" class="btn btn-warning">Edit</a>
                <a href="list.php" class="btn btn-secondary">← Back to List</a>
            </div>
        </div>
        
        <?php if ($successMessage): ?>
        <div class="alert alert-success">
            <?php echo $successMessage; ?>
        </div>
        <?php endif; ?>
        
        <?php if ($errorMessage): ?>
        <div class="alert alert-danger">
            <?php echo $errorMessage; ?>
        </div>
        <?php endif; ?>
        
        <div class="book-details">
            <div class="details-grid">
                <div class="detail-group">
                    <label>ISBN</label>
                    <p class="detail-value"><code><?php echo Security::sanitizeInput($book['isbn']); ?></code></p>
                </div>
                
                <div class="detail-group">
                    <label>Author</label>
                    <p class="detail-value"><?php echo Security::sanitizeInput($book['author']); ?></p>
                </div>
                
                <div class="detail-group">
                    <label>Publisher</label>
                    <p class="detail-value"><?php echo Security::sanitizeInput($book['publisher'] ?? 'N/A'); ?></p>
                </div>
                
                <div class="detail-group">
                    <label>Publication Year</label>
                    <p class="detail-value"><?php echo $book['publication_year'] ?? 'N/A'; ?></p>
                </div>
                
                <div class="detail-group">
                    <label>Genre</label>
                    <p class="detail-value">
                        <?php if ($book['genre']): ?>
                            <span class="badge badge-info"><?php echo Security::sanitizeInput($book['genre']); ?></span>
                        <?php else: ?>
                            <span class="text-secondary">N/A</span>
                        <?php endif; ?>
                    </p>
                </div>
                
                <div class="detail-group">
                    <label>Pages</label>
                    <p class="detail-value"><?php echo $book['pages'] ?? 'N/A'; ?></p>
                </div>
                
                <div class="detail-group">
                    <label>Available Copies</label>
                    <p class="detail-value">
                        <span class="badge <?php echo $book['copies_available'] > 0 ? 'badge-success' : 'badge-danger'; ?>">
                            <?php echo $book['copies_available']; ?>
                        </span>
                    </p>
                </div>
                
                <div class="detail-group">
                    <label>Total Copies</label>
                    <p class="detail-value"><?php echo $book['total_copies']; ?></p>
                </div>
            </div>
            
            <?php if ($book['description']): ?>
            <div class="description-section">
                <h3>Description</h3>
                <p><?php echo Security::sanitizeInput($book['description']); ?></p>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($loanHistory)): ?>
            <div class="loan-history-section">
                <h3>Loan History</h3>
                <div class="table-container">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Member</th>
                                <th>Loan Date</th>
                                <th>Due Date</th>
                                <th>Return Date</th>
                                <th>Status</th>
                                <th>Fine</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($loanHistory as $loan): ?>
                            <tr>
                                <td><?php echo Security::sanitizeInput($loan['first_name'] . ' ' . $loan['last_name']); ?></td>
                                <td><?php echo date('M d, Y', strtotime($loan['loan_date'])); ?></td>
                                <td><?php echo date('M d, Y', strtotime($loan['due_date'])); ?></td>
                                <td><?php echo $loan['return_date'] ? date('M d, Y', strtotime($loan['return_date'])) : 'Not returned'; ?></td>
                                <td>
                                    <span class="badge badge-<?php echo $loan['status'] === 'returned' ? 'success' : 'warning'; ?>">
                                        <?php echo ucfirst($loan['status']); ?>
                                    </span>
                                </td>
                                <td>$<?php echo number_format($loan['fine_amount'], 2); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>
