<?php
/**
 * List All Books - Read Operation
 */

require_once '../config/config.php';
require_once '../models/Book.php';

Security::requireLogin();

$bookModel = new Book();

// Get pagination
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;

// Get books
$books = $bookModel->getAll($page);
$totalBooks = $bookModel->getCount();
$totalPages = ceil($totalBooks / ITEMS_PER_PAGE);

// Handle success/error messages
$successMessage = $_SESSION['success_message'] ?? '';
$errorMessage = $_SESSION['error_message'] ?? '';
unset($_SESSION['success_message']);
unset($_SESSION['error_message']);

$pageTitle = 'Books List';
$csrfToken = Security::generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle . ' - ' . APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1><?php echo $pageTitle; ?></h1>
            <div class="header-actions">
                <a href="add.php" class="btn btn-success">
                    <span class="btn-icon">➕</span> Add New Book
                </a>
                <a href="search.php" class="btn btn-primary">
                    <span class="btn-icon">🔍</span> Advanced Search
                </a>
            </div>
        </div>
        
        <?php if ($successMessage): ?>
        <div class="alert alert-success">
            <?php echo $successMessage; ?>
        </div>
        <?php endif; ?>
        
        <?php if ($errorMessage): ?>
        <div class="alert alert-danger">
            <?php echo $errorMessage; ?>
        </div>
        <?php endif; ?>
        
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>ISBN</th>
                        <th>Title</th>
                        <th>Author</th>
                        <th>Genre</th>
                        <th>Available</th>
                        <th>Total</th>
                        <th>Year</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($books)): ?>
                    <tr>
                        <td colspan="8" class="text-center">No books found. <a href="add.php">Add the first book</a></td>
                    </tr>
                    <?php else: ?>
                        <?php foreach ($books as $book): ?>
                        <tr>
                            <td><code><?php echo Security::sanitizeInput($book['isbn']); ?></code></td>
                            <td class="title-cell"><?php echo Security::sanitizeInput($book['title']); ?></td>
                            <td><?php echo Security::sanitizeInput($book['author']); ?></td>
                            <td>
                                <?php if ($book['genre']): ?>
                                    <span class="badge badge-info"><?php echo Security::sanitizeInput($book['genre']); ?></span>
                                <?php else: ?>
                                    <span class="text-secondary">N/A</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?php echo $book['copies_available'] > 0 ? 'badge-success' : 'badge-danger'; ?>">
                                    <?php echo $book['copies_available']; ?>
                                </span>
                            </td>
                            <td><?php echo $book['total_copies']; ?></td>
                            <td><?php echo $book['publication_year'] ?? 'N/A'; ?></td>
                            <td>
                                <div class="action-buttons">
                                    <a href="view.php?id=<?php echo $book['book_id']; ?>" class="btn btn-sm btn-info" title="View">👁️</a>
                                    <a href="edit.php?id=<?php echo $book['book_id']; ?>" class="btn btn-sm btn-warning" title="Edit">✏️</a>
                                    <form method="POST" action="delete.php" style="display:inline;" class="delete-form">
                                        <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                                        <input type="hidden" name="book_id" value="<?php echo $book['book_id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-danger" title="Delete" onclick="return confirm('Delete this book?');">🗑️</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=1" class="btn btn-sm">First</a>
                <a href="?page=<?php echo $page - 1; ?>" class="btn btn-sm">Previous</a>
            <?php endif; ?>
            
            <span class="pagination-info">
                Page <?php echo $page; ?> of <?php echo $totalPages; ?> 
                (<?php echo $totalBooks; ?> total books)
            </span>
            
            <?php if ($page < $totalPages): ?>
                <a href="?page=<?php echo $page + 1; ?>" class="btn btn-sm">Next</a>
                <a href="?page=<?php echo $totalPages; ?>" class="btn btn-sm">Last</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>
