<?php
/**
 * List All Loans
 */

require_once '../config/config.php';
require_once '../models/Loan.php';

Security::requireLogin();

$loanModel = new Loan();

$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$status = isset($_GET['status']) ? Security::sanitizeInput($_GET['status']) : null;

$loans = $loanModel->getAll($page, ITEMS_PER_PAGE, $status);
$totalLoans = $loanModel->getCount($status);
$totalPages = ceil($totalLoans / ITEMS_PER_PAGE);

$successMessage = $_SESSION['success_message'] ?? '';
$errorMessage = $_SESSION['error_message'] ?? '';
unset($_SESSION['success_message']);
unset($_SESSION['error_message']);

$pageTitle = 'Loans Management';
$csrfToken = Security::generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle . ' - ' . APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1><?php echo $pageTitle; ?></h1>
            <div class="header-actions">
                <a href="issue.php" class="btn btn-success">
                    <span class="btn-icon">➕</span> Issue New Loan
                </a>
                <a href="overdue.php" class="btn btn-danger">
                    <span class="btn-icon">⚠️</span> Overdue Books
                </a>
            </div>
        </div>
        
        <?php if ($successMessage): ?>
        <div class="alert alert-success">
            <?php echo $successMessage; ?>
        </div>
        <?php endif; ?>
        
        <?php if ($errorMessage): ?>
        <div class="alert alert-danger">
            <?php echo $errorMessage; ?>
        </div>
        <?php endif; ?>
        
        <!-- Filter Tabs -->
        <div class="filter-tabs">
            <a href="?status=" class="tab-btn <?php echo !$status ? 'active' : ''; ?>">All Loans</a>
            <a href="?status=active" class="tab-btn <?php echo $status === 'active' ? 'active' : ''; ?>">Active</a>
            <a href="?status=returned" class="tab-btn <?php echo $status === 'returned' ? 'active' : ''; ?>">Returned</a>
            <a href="?status=overdue" class="tab-btn <?php echo $status === 'overdue' ? 'active' : ''; ?>">Overdue</a>
        </div>
        
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>Book</th>
                        <th>Member</th>
                        <th>Loan Date</th>
                        <th>Due Date</th>
                        <th>Return Date</th>
                        <th>Status</th>
                        <th>Fine</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($loans)): ?>
                    <tr>
                        <td colspan="8" class="text-center">No loans found. <a href="issue.php">Issue a new loan</a></td>
                    </tr>
                    <?php else: ?>
                        <?php foreach ($loans as $loan): ?>
                        <tr>
                            <td><?php echo Security::sanitizeInput($loan['title']); ?></td>
                            <td><?php echo Security::sanitizeInput($loan['first_name'] . ' ' . $loan['last_name']); ?></td>
                            <td><?php echo date('M d, Y', strtotime($loan['loan_date'])); ?></td>
                            <td><?php echo date('M d, Y', strtotime($loan['due_date'])); ?></td>
                            <td><?php echo $loan['return_date'] ? date('M d, Y', strtotime($loan['return_date'])) : '-'; ?></td>
                            <td>
                                <span class="badge badge-<?php echo $loan['status'] === 'returned' ? 'success' : ($loan['status'] === 'overdue' ? 'danger' : 'warning'); ?>">
                                    <?php echo ucfirst($loan['status']); ?>
                                </span>
                            </td>
                            <td>$<?php echo number_format($loan['fine_amount'], 2); ?></td>
                            <td>
                                <div class="action-buttons">
                                    <?php if ($loan['status'] === 'active'): ?>
                                    <a href="return.php?id=<?php echo $loan['loan_id']; ?>" class="btn btn-sm btn-success" title="Return Book">↩️</a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=1<?php echo $status ? '&status=' . $status : ''; ?>" class="btn btn-sm">First</a>
                <a href="?page=<?php echo $page - 1; ?><?php echo $status ? '&status=' . $status : ''; ?>" class="btn btn-sm">Previous</a>
            <?php endif; ?>
            
            <span class="pagination-info">
                Page <?php echo $page; ?> of <?php echo $totalPages; ?>
            </span>
            
            <?php if ($page < $totalPages): ?>
                <a href="?page=<?php echo $page + 1; ?><?php echo $status ? '&status=' . $status : ''; ?>" class="btn btn-sm">Next</a>
                <a href="?page=<?php echo $totalPages; ?><?php echo $status ? '&status=' . $status : ''; ?>" class="btn btn-sm">Last</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>
