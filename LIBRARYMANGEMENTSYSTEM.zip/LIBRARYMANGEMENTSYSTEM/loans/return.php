<?php
/**
 * Return Book - Process loan return
 */

require_once '../config/config.php';
require_once '../models/Loan.php';

Security::requireLogin();

$loanModel = new Loan();

$loanId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($loanId <= 0) {
    $_SESSION['error_message'] = 'Invalid loan ID.';
    header('Location: list.php');
    exit;
}

$loan = $loanModel->getById($loanId);

if (!$loan) {
    $_SESSION['error_message'] = 'Loan not found.';
    header('Location: list.php');
    exit;
}

$success = '';
$error = '';
$csrfToken = Security::generateCSRFToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !Security::verifyCSRFToken($_POST['csrf_token'])) {
        $error = 'Invalid security token. Please try again.';
    } else {
        $fine = floatval($_POST['fine_amount'] ?? 0);
        
        if ($fine < 0) {
            $error = 'Fine amount cannot be negative.';
        } else {
            try {
                if ($loanModel->returnBook($loanId, $fine)) {
                    $_SESSION['success_message'] = 'Book returned successfully!';
                    header('Location: list.php');
                    exit;
                } else {
                    $error = 'Failed to process return. Please try again.';
                }
            } catch (Exception $e) {
                error_log('Return book error: ' . $e->getMessage());
                $error = 'An error occurred while processing the return.';
            }
        }
    }
}

// Calculate overdue fine
$fineAmount = $loanModel->calculateFine($loanId);

$pageTitle = 'Return Book';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle . ' - ' . APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1><?php echo $pageTitle; ?></h1>
            <a href="list.php" class="btn btn-secondary">← Back to List</a>
        </div>
        
        <?php if ($error): ?>
        <div class="alert alert-danger">
            <?php echo $error; ?>
        </div>
        <?php endif; ?>
        
        <div class="form-container">
            <div class="return-details">
                <div class="details-grid">
                    <div class="detail-group">
                        <label>Book</label>
                        <p class="detail-value"><?php echo Security::sanitizeInput($loan['title']); ?></p>
                    </div>
                    
                    <div class="detail-group">
                        <label>ISBN</label>
                        <p class="detail-value"><code><?php echo Security::sanitizeInput($loan['isbn']); ?></code></p>
                    </div>
                    
                    <div class="detail-group">
                        <label>Member</label>
                        <p class="detail-value"><?php echo Security::sanitizeInput($loan['first_name'] . ' ' . $loan['last_name']); ?></p>
                    </div>
                    
                    <div class="detail-group">
                        <label>Loan Date</label>
                        <p class="detail-value"><?php echo date('M d, Y', strtotime($loan['loan_date'])); ?></p>
                    </div>
                    
                    <div class="detail-group">
                        <label>Due Date</label>
                        <p class="detail-value"><?php echo date('M d, Y', strtotime($loan['due_date'])); ?></p>
                    </div>
                    
                    <div class="detail-group">
                        <label>Days Overdue</label>
                        <p class="detail-value">
                            <?php
                            $daysOverdue = max(0, ceil((time() - strtotime($loan['due_date'])) / (60 * 60 * 24)));
                            echo $daysOverdue > 0 ? '<span class="badge badge-danger">' . $daysOverdue . ' days</span>' : '<span class="badge badge-success">On time</span>';
                            ?>
                        </p>
                    </div>
                </div>
            </div>
            
            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                
                <div class="form-group">
                    <label for="fine_amount">Fine Amount ($)</label>
                    <input type="number" id="fine_amount" name="fine_amount" class="form-control" 
                           value="<?php echo number_format($fineAmount, 2); ?>" 
                           step="0.01" min="0">
                    <small>Calculated overdue fine: $<?php echo number_format($fineAmount, 2); ?></small>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-success">Process Return</button>
                    <a href="list.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>
