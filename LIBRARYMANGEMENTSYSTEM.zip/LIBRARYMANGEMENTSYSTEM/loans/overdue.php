<?php
/**
 * Overdue Books Report
 */

require_once '../config/config.php';
require_once '../models/Loan.php';

Security::requireLogin();

$loanModel = new Loan();

$overdueLoans = $loanModel->getOverdueLoans();
$totalFines = 0;

foreach ($overdueLoans as $loan) {
    $totalFines += $loanModel->calculateFine($loan['loan_id']);
}

$pageTitle = 'Overdue Books Report';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle . ' - ' . APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1><?php echo $pageTitle; ?></h1>
            <a href="list.php" class="btn btn-secondary">← Back to Loans</a>
        </div>
        
        <?php if (empty($overdueLoans)): ?>
        <div class="alert alert-success">
            No overdue books! All loans are current.
        </div>
        <?php else: ?>
        <div class="alert alert-danger">
            <strong><?php echo count($overdueLoans); ?></strong> overdue loan(s) with 
            <strong>$<?php echo number_format($totalFines, 2); ?></strong> in total fines.
        </div>
        
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>Book Title</th>
                        <th>ISBN</th>
                        <th>Member Name</th>
                        <th>Email</th>
                        <th>Due Date</th>
                        <th>Days Overdue</th>
                        <th>Fine (@ $0.50/day)</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($overdueLoans as $loan): ?>
                    <tr class="overdue-row">
                        <td><strong><?php echo Security::sanitizeInput($loan['title']); ?></strong></td>
                        <td><code><?php echo Security::sanitizeInput($loan['isbn']); ?></code></td>
                        <td><?php echo Security::sanitizeInput($loan['first_name'] . ' ' . $loan['last_name']); ?></td>
                        <td><a href="mailto:<?php echo Security::sanitizeInput($loan['email']); ?>"><?php echo Security::sanitizeInput($loan['email']); ?></a></td>
                        <td><?php echo date('M d, Y', strtotime($loan['due_date'])); ?></td>
                        <td>
                            <span class="badge badge-danger"><?php echo $loan['days_overdue']; ?> days</span>
                        </td>
                        <td>
                            <?php 
                            $fine = $loanModel->calculateFine($loan['loan_id']);
                            ?>
                            <strong>$<?php echo number_format($fine, 2); ?></strong>
                        </td>
                        <td>
                            <a href="return.php?id=<?php echo $loan['loan_id']; ?>" class="btn btn-sm btn-success">Process Return</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>
