<?php
/**
 * Issue New Loan
 */

require_once '../config/config.php';
require_once '../models/Loan.php';
require_once '../models/Book.php';
require_once '../models/Member.php';

Security::requireLogin();

$loanModel = new Loan();
$bookModel = new Book();
$memberModel = new Member();

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !Security::verifyCSRFToken($_POST['csrf_token'])) {
        $error = 'Invalid security token. Please try again.';
    } else {
        $bookId = Security::sanitizeInput($_POST['book_id'] ?? '');
        $memberId = Security::sanitizeInput($_POST['member_id'] ?? '');
        $loanDays = Security::sanitizeInput($_POST['loan_days'] ?? 14);
        
        if (empty($bookId) || empty($memberId)) {
            $error = 'Please select both book and member.';
        } elseif (!is_numeric($loanDays) || $loanDays < 1 || $loanDays > 60) {
            $error = 'Loan period must be between 1 and 60 days.';
        } else {
            try {
                // Verify book exists
                $book = $bookModel->getById($bookId);
                if (!$book) {
                    $error = 'Book not found.';
                } else if ($book['copies_available'] <= 0) {
                    $error = 'This book is not available.';
                } else {
                    // Verify member exists
                    $member = $memberModel->getById($memberId);
                    if (!$member) {
                        $error = 'Member not found.';
                    } else if ($member['status'] !== 'active') {
                        $error = 'This member is not active.';
                    } else {
                        if ($loanModel->issueLoan($bookId, $memberId, $loanDays)) {
                            $_SESSION['success_message'] = 'Loan issued successfully!';
                            header('Location: list.php');
                            exit;
                        } else {
                            $error = 'Failed to issue loan. Please try again.';
                        }
                    }
                }
            } catch (Exception $e) {
                error_log('Issue loan error: ' . $e->getMessage());
                $error = 'An error occurred while issuing the loan.';
            }
        }
    }
}

$csrfToken = Security::generateCSRFToken();
$pageTitle = 'Issue New Loan';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle . ' - ' . APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1><?php echo $pageTitle; ?></h1>
            <a href="list.php" class="btn btn-secondary">← Back to List</a>
        </div>
        
        <?php if ($error): ?>
        <div class="alert alert-danger">
            <?php echo $error; ?>
        </div>
        <?php endif; ?>
        
        <div class="form-container">
            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                
                <div class="form-grid">
                    <div class="form-group full-width">
                        <label for="book_id">Book <span class="required">*</span></label>
                        <select id="book_id" name="book_id" class="form-control" required>
                            <option value="">-- Select a book --</option>
                            <?php
                            $books = $bookModel->getAll(1, 1000);
                            foreach ($books as $book):
                                if ($book['copies_available'] > 0):
                            ?>
                            <option value="<?php echo $book['book_id']; ?>">
                                <?php echo Security::sanitizeInput($book['title'] . ' - ' . $book['author']); ?>
                                (Available: <?php echo $book['copies_available']; ?>)
                            </option>
                            <?php 
                                endif;
                            endforeach; 
                            ?>
                        </select>
                    </div>
                    
                    <div class="form-group full-width">
                        <label for="member_id">Member <span class="required">*</span></label>
                        <select id="member_id" name="member_id" class="form-control" required>
                            <option value="">-- Select a member --</option>
                            <?php
                            $members = $memberModel->getAll(1, 1000, 'active');
                            foreach ($members as $member):
                            ?>
                            <option value="<?php echo $member['member_id']; ?>">
                                <?php echo Security::sanitizeInput($member['first_name'] . ' ' . $member['last_name'] . ' (' . $member['email'] . ')'); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="loan_days">Loan Period (Days)</label>
                        <input type="number" id="loan_days" name="loan_days" class="form-control" value="14" min="1" max="60">
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-success">Issue Loan</button>
                    <a href="list.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>
